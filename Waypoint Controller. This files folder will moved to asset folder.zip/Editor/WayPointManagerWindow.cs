using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
//this script will not be attached. But its cs file location is Editor folder
public class WayPointManagerWindow : EditorWindow
{
    [MenuItem("WayPoint/Waypoint Editor Tools")]
    public static void ShowWindow()
    {
        GetWindow<WayPointManagerWindow>("Waypoint Editor Tools");
    }
    public Transform waypointOrigin;
    private void OnGUI()
    {
        SerializedObject obj= new SerializedObject(this);
        EditorGUILayout.PropertyField(obj.FindProperty("waypointOrigin"));
        if(waypointOrigin==null)
        {
            EditorGUILayout.HelpBox("Please Assign a Waypoint Origin Transform. ", MessageType.Warning);

        }
        else
        {
            EditorGUILayout.BeginVertical("box");
            CreateButtons();
            EditorGUILayout.EndVertical();
        }
        obj.ApplyModifiedProperties();
    }
    
    void CreateButtons()
    {
        if(GUILayout.Button("Create Waypoint"))
        {
            createWayPoint();
        }
    }
    void createWayPoint()
    {
        GameObject waypointObject = new GameObject("Waypoint " + waypointOrigin.childCount, typeof(WayPoint));
        waypointObject.transform.SetParent(waypointOrigin, false);

        WayPoint waypoint = waypointObject.GetComponent<WayPoint>();
        if(waypointOrigin.childCount>1)
        {
            waypoint.previousWayPoint= waypointOrigin.GetChild(waypointOrigin.childCount-2).GetComponent<WayPoint>();
            waypoint.previousWayPoint.nextWayPoint = waypoint;

            waypoint.transform.position= waypoint.previousWayPoint.transform.position;
            waypoint.transform.forward= waypoint.previousWayPoint.transform.forward;

        }
        Selection.activeGameObject=waypoint.gameObject;
    }
}
